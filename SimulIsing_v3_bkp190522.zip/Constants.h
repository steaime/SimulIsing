#pragma once
#ifndef CONSTANTS_H
#define CONSTANTS_H

// Global simulation parameters (cannot be changed at runtime)

#define VERBOSE 0
#define DEBUG_MODE 0

#define N_DIM 2			// Number of lattice dimensions.

#define RATE_EPS 1e-20  // Minimum rate accepted (rates cannot be zero or negative).
						// When rates get 0 or negative, they are set to RATE_EPS
#define ALPHA_EPS 0     // Minimum alpha value accepted (alphas cannot be negative).
						// When alphas get 0 or negative, they are set to ALPHA_EPS

#define BAD_VALUE -100


#define INI_MAXNUMDIM 5
#define INI_MAXNUMSIM 100
#define INI_NOISE_MAXPARAMS 3
#define INI_TPROT_MAXPARAMS 5


						
// Correlation parameters

#define CORR_BINARY 1		// Correlate the rates (0) or the solid/fluid binary state (1)
#define CORR_NORM_X0 1		// Normalize (1) / do not normalize (0) all correlation functions by the dx=0 value






#define MAX_SOLID_RATE_RATIO 5.0 // Default threshold separating "slow/solid" sites from "fast/fluid" sites
						// Site i will be slow/solid site if _rates[i] < MAX_SOLID_RATE_RATIO/DEF_TAU0
						// (or the analogous ratio calculated using runtime defined values)






// Simulation parameters

/* Random thermal jump settings: every simulation step 
- takes val_current as the current value of the cell,
- computes val_target using the expression based on actual values of the neighbors
- if RANDOM_NOISE_LOG==0:	generates a random number with Gaussian probability distribution
							centered around val_target with variance proportional to effective temperature
							specify proportionality constant. Sets the new rate to this random number
  if RANDOM_NOISE_LOG==1:	generates a random number with Gaussian probability distribution
							centered around log10(val_target) with variance proportional to effective temperature
							specify proportionality constant. Sets the new rate to pow(10, this random number)
*/
#define RANDOM_NOISE_COEFF 1.0
#define RANDOM_NOISE_LOG 1

/* Random simulation step default parameters */

#define DEF_SIM_TEMP 0.0			// Effective temperature: sets the random jump 
									// on top of deterministic dynamics (see RANDOM_NOISE_COEFF)
#define DEF_SIMSTEP_MAX_ITER 10000	// Maximum number of simulation steps
#define DEF_SIM_CONV_PREC 1e-40		// Convergence precision, to decide if simulation has converged
									// Set to 0 not to check for convergence (in this case every step
									// will have the maximum number of iterations)
									// Suggestion: for DEF_DEVIATION_LOG==0, try DEF_SIM_CONV_PREC=1e-6
#define DEF_DEVIATION_LOG 1			// If 0: deviation between current configuration and target configuration
									//       is computed using the difference of relaxation rates
									// If 1: deviation is computed using the difference of log10(rate)
									//       (to give equal weight to slow and fast mode)
//#define DEF_EQ_PROTOCOL 0			// Temperature profile during equilibration
									// check enum TemperatureProtocol in MontecarloParameters.h
#define DEF_EQ_RUN_NUM 1			// Run the whole equilibration protocol (until convergence or for DEF_SIMSTEP_MAX_ITER steps)
									// DEF_EQ_RUN_NUM times. Useful for DEF_EQ_PROTOCOL!=0





// Default simulation parameters



// Default output parameters

#define DEF_INI_FILE "C:\\Users\\STEAIME\\Documents\\Montpellier\\Ludox\\Ising\\SimulIsing\\SimulIsing_v3\\simParams.ini"

#define DEF_OUT_FILE "C:\\Users\\STEAIME\\Documents\\Montpellier\\Ludox\\Ising\\SimulIsing\\out\\out_debug\\tmp.txt"
#define DEF_OUT_FOLDER "C:\\Users\\STEAIME\\Documents\\Montpellier\\Ludox\\Ising\\SimulIsing\\out\\out_debug\\"
#define DEF_IMGOUT_FOLDER "C:\\Users\\STEAIME\\Documents\\Montpellier\\Ludox\\Ising\\SimulIsing\\out_debug\\imgs\\"





enum TemperatureProtocol {
	CONSTANT, LINRAMP, EXPRAMP, PWRRAMP
};


enum NoiseTypes
{
	NONOISE, WHITE_FLAT, WHITE_GAUSS, WHITE_LOGNORM
};

/*
NoiseTypes::NONOISE			No parameter required, all values equal to _avg
NoiseTypes::WHITE_FLAT		One parameter required (the noise relative variance)
							NOTE:   if average==0 the parameter will be interpreted as the
									absolute variance, instead of the relative variance.
									Random numbers generated with flat distribution in the
									[_avg-amplitude, _avg+amplitude] interval, with
									amplitude = sqrt(3 * relative_variance * _avg)
NoiseTypes::WHITE_GAUSS		One parameter required (the noise relative variance)
							Random numbers generated following a Gauss distribution
							with the given variance
NoiseTypes::WHITE_LOGNORM	One parameter required (the noise relative variance)
							Random numbers generated following a Lognormal distribution
							with the given variance
*/


enum SimStatus {
	NOT_INITIALIZED, INITIALIZED
};

enum EqDetails {
	AVRATE, DEV, RATECHANGE, STDRATE, FASTSITES
};

#define NUM_EQ_DETAILS 5
const std::string strEqLabels[NUM_EQ_DETAILS] = { "avrate", "dev", "ratechange", "stdrate", "fastsites" };






/*


// Model Parameters (OBSOLETE)

#define DEF_N_SITES 16
#define DEF_INIT_RATE 1.0		// Average initial rate (for initialization and preshearing) ***OBSOLETE***
#define DEF_USE_PBC true

#define DEF_NOISE_TYPE NoiseTypes::WHITE_GAUSS
#define DEF_BETA 2.0			// According to Domenico, no phase transition for Beta<=1. Fix Beta=2

#define SAMPLE_PARAMS 5

#if SAMPLE_PARAMS==0:
#if DEF_NOISE_TYPE==NoiseTypes::WHITE_GAUSS:

/////// PARAMETERS FOR INITIAL MODEL VALIDATION /////////
#define DEF_N 2.0
#define DEF_K 1.0
#define DEF_TAU0 10000
#define DEF_OMEGA 3.14
#define DEF_ALPHA_AVG 1.26e-4
#define DEF_ALPHANOISE 0
#endif

#elif SAMPLE_PARAMS==1:
#if DEF_NOISE_TYPE==NoiseTypes::WHITE_GAUSS:

/////// PARAMETERS FOR PNIPAM STRESS-CONTROLLED SAMPLE /////////
#if 0:
#define DEF_N 2.5				// Slope of rate(gamma) in fluidized regime
#define DEF_K 0.1				// Vertical shift (log scale) in rate(gamma) in fluidized regime
#define DEF_ALPHA_AVG 2.115e-5	// Controls yield strain
#else:
#define DEF_N 2					// Slope of rate(gamma) in fluidized regime
#define DEF_K 0.075				// Vertical shift (log scale) in rate(gamma) in fluidized regime
#define DEF_ALPHA_AVG 1.45e-5	// Controls yield strain
#endif
#define DEF_TAU0 120000			// 1/Relaxation rate in solid regime
#define DEF_OMEGA 0.157			// omega=2*pi/period. Period: 40s
#define DEF_ALPHANOISE 0

#endif

#elif SAMPLE_PARAMS==2:
#if DEF_NOISE_TYPE==NoiseTypes::WHITE_GAUSS:

/////// PARAMETERS FOR PNIPAM STRAIN-CONTROLLED (PRESHEARED) SAMPLE /////////
#define DEF_N 2					// Slope of rate(gamma) in fluidized regime
#define DEF_K 0.00125			// Vertical shift (log scale) in rate(gamma) in fluidized regime
#define DEF_ALPHA_AVG 1.67e-8	// Controls yield strain (for tau0=120000s use 1.296e-8)
#define DEF_TAU0 90000			// 1/Relaxation rate in solid regime
#define DEF_OMEGA 3.14			// omega=2*pi/period. Period: 2s
#define DEF_ALPHANOISE 0.11		// Relative variance of white noise (Gaussian PDF)

#endif

#elif SAMPLE_PARAMS==3:
#if DEF_NOISE_TYPE==NoiseTypes::WHITE_GAUSS:

/////// PARAMETERS FOR 88% EMULSION /////////

#define DEF_N 15
#define DEF_K 1e13
#define DEF_ALPHA_AVG 1e10
#define DEF_TAU0 617
#define DEF_OMEGA 6.28
#define DEF_ALPHANOISE 0.0

#endif

#elif SAMPLE_PARAMS==4:
#if DEF_NOISE_TYPE==NoiseTypes::WHITE_GAUSS:

/////// PARAMETERS FOR 64% EMULSION (LONGER EXP) /////////

#define DEF_N 8
#define DEF_K 1e9
#define DEF_ALPHA_AVG 8.8e5
#define DEF_TAU0 617
#define DEF_OMEGA 6.28
#define DEF_ALPHANOISE 0.35
#endif

#elif SAMPLE_PARAMS==5:
#if DEF_NOISE_TYPE==NoiseTypes::WHITE_GAUSS:


/////// PARAMETERS FOR LUDOX PHI45% SAMPLE /////////
#define OLD_LUDOX45_PARAMS 0

#if OLD_LUDOX45_PARAMS:
#define DEF_N 4.0
#define DEF_K 64.0
#define DEF_TAU0 7500
#define DEF_OMEGA 3.14
#define DEF_ALPHA_AVG 0.0094
#define DEF_ALPHANOISE 0.3
#else:
#define DEF_N 3.0
#define DEF_K 8.0
#define DEF_TAU0 9000
#define DEF_OMEGA 3.14
#define DEF_ALPHA_AVG 0.001112  //0.001071
#define DEF_ALPHANOISE 0.08
#endif
#else:
#define DEF_N 3.0
#define DEF_K 8.0
#define DEF_TAU0 9000
#define DEF_OMEGA 3.14
#define DEF_ALPHA_AVG 0.001112  //0.001071
#define DEF_ALPHANOISE 0.08
#endif

#elif SAMPLE_PARAMS==6:
#if DEF_NOISE_TYPE==NoiseTypes::WHITE_GAUSS:

/////// PARAMETERS FOR 70% EMULSION /////////

#define DEF_N 8
#define DEF_K 1.59e9
#define DEF_ALPHA_AVG 2.241e5
#define DEF_TAU0 4600
#define DEF_OMEGA 6.28
#define DEF_ALPHANOISE 0.1
#endif
#endif

*/




#endif
