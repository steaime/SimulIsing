#include "InitialConditions.h"

InitialConditions::InitialConditions()
{
}

InitialConditions::~InitialConditions()
{
}
