#pragma once
#ifndef INITIAL_CONDITIONS_H
#define INITIAL_CONDITIONS_H

#include "stdafx.h"
#include "Constants.h"

class InitialConditions {
public:
	InitialConditions();
	~InitialConditions();
private:

};

#endif // !INITIAL_CONDITIONS_H
