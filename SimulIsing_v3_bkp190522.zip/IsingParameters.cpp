#include "IsingParameters.h"

IsingParameters::IsingParameters()
{
	for (int i = 0; i < N_DIM; i++) {
		LatticeShape[i] = 0;
	}
	UsePBC = true;
	K = 1.0;
	Tau0 = 1.0;
	Omega = 1.0;
	Beta = 1.0;
	AlphaAverage = 0.0;
	// initialize AlphaNoise?
}

IsingParameters::IsingParameters(int* _LatticeShape, double _n, double _K, double _Tau0, double _Omega, double _Beta,
								Noise _AlphaNoise, bool _UsePBC) {
	_num_sites = 1;
	for (int i = 0; i < N_DIM; i++) {
		LatticeShape[i] = _LatticeShape[i];
		_num_sites *= LatticeShape[i];
	}
	K = _K;
	n = _n;
	Tau0 = _Tau0;
	Omega = _Omega;
	Beta = _Beta;
	UsePBC = _UsePBC;
	AlphaAverage = _AlphaNoise.GetAverage();
	AlphaNoise.CopyFrom(_AlphaNoise);
}

IsingParameters::IsingParameters(std::string sParamFile) {
	ConfigParams params(sParamFile);
	Initialize(params);
}

IsingParameters::IsingParameters(ConfigParams &params) {
	Initialize(params);
}

IsingParameters::~IsingParameters()
{
}

void IsingParameters::Initialize(ConfigParams &params) {
	int _LatticeShape[INI_MAXNUMDIM];
	for (int i = 0; i < INI_MAXNUMDIM; i++) {
		_LatticeShape[i] = params.piLatticeShape[i];
	}
	int _nSites = params.iNumSites;
	_num_sites = 1;
	for (int i = 0; i < N_DIM; i++) {
		if (_LatticeShape[i] <= 0) {
			LatticeShape[i] = _nSites;
		}
		else {
			LatticeShape[i] = _LatticeShape[i];
		}
		_num_sites *= LatticeShape[i];
	}

	K = params.K;
	n = params.n;
	Tau0 = params.Tau0;
	Omega = params.Omega;
	Beta = params.Beta;
	UsePBC = params.dUsePBC;
	AlphaNoise.Initialize(params.iAlphaNoiseType, params.dAlphaAvg, params.pdAlphaParams);
}

void IsingParameters::CopyFrom(IsingParameters params) 
{
	_num_sites = 1;
	for (int i = 0; i < N_DIM; i++) {
		LatticeShape[i] = params.LatticeShape[i];
		_num_sites *= LatticeShape[i];
	}
	UsePBC = params.UsePBC;
	K = params.K;
	n = params.n;
	Tau0 = params.Tau0;
	Omega = params.Omega;
	AlphaAverage = params.AlphaAverage;
	Beta = params.Beta;
	AlphaNoise = params.AlphaNoise;
}

int IsingParameters::NumSites(bool force_calc) {
	if (force_calc) {
		int res = 1;
		for (int i = 0; i < N_DIM; i++) {
			res *= LatticeShape[i];
		}
		return res;
	}
	else {
		return _num_sites;
	}
}

void IsingParameters::GetSiteCoordinates(int site, int* res) {
	for (int i = 0; i < N_DIM; i++) {
		int sect = 1;
		for (int j = i+1; j < N_DIM; j++) {
			sect *= LatticeShape[j];
		}
		int coord = site / sect;
		site -= coord * sect;
		res[i] = coord;
	}
}

int IsingParameters::SiteID(int* site_coords) {
	int res = 0;
	for (int i = 0; i < N_DIM; i++) {
		int sect = 1;
		for (int j = i + 1; j < N_DIM; j++) {
			sect *= LatticeShape[j];
		}
		res += site_coords[i] * sect;
		}
	return res;
}

int IsingParameters::ProjectionArea(int axis) {
	if (axis >= 0 && axis < N_DIM) {
		int res = 1;
		for (int i = 0; i < N_DIM; i++) {
			if (i != axis) {
				res *= LatticeShape[i];
			}
		}
		return res;
	}
	else {
		return -1;
	}
}

double IsingParameters::GetMeanFieldGamma(double rate) {
	if (rate > 1 / Tau0) {
#if DEBUG_MODE:
		double term1 = rate / Omega;
		double term2 = 1.0 / (Omega * Tau0);
		double term3 = K / (term1 - term2);
		double term4 = AlphaAverage * pow(Omega / rate, Beta);
		double term5 = term3 - term4;
		double term6 = pow(term5, 1.0 / n);
		double res = 1.0 / term6;
#else:
		double res = 1.0 / pow(K / (rate / Omega - 1.0 / (Omega * Tau0)) - AlphaAverage * pow(Omega / rate, Beta), 1.0/n); // Domenico's eq. 18
#endif
		return res;
	}
	else if (rate == 1 / Tau0) {
		return 0;
	}
	else {
		return -1;
	}
}

double IsingParameters::Gamma0() {
	return 1.0 / Tau0;
}

double IsingParameters::Gammac() {
	return Gamma0()*(1 + 2 / (Beta - 1));
}

double IsingParameters::Kc() {
	return 4 * AlphaAverage*Beta*pow(Omega, Beta - 1)*pow(Gamma0(), 2) / (pow(Beta - 1, 2)*pow(Gammac(), Beta + 1));
}

double IsingParameters::gammac() {
	return pow(AlphaAverage*pow(Omega*Tau0, Beta)*pow((Beta - 1) / (Beta + 1), Beta + 1), -1.0 / n);
}
