#pragma once
#ifndef ISING_PARAMETERS_H
#define ISING_PARAMETERS_H

#include "stdafx.h"
#include "Constants.h"
#include "Noise.h"
#include "ConfigReader.h"

class IsingParameters
{
public:
	IsingParameters();
	IsingParameters(int* _LatticeShape, double _n, double _K, double _Tau0, double _Omega, double _Beta, 
					Noise _AlphaNoise, bool _UsePBC);
	IsingParameters(std::string sParamFile);
	IsingParameters(ConfigParams &params);
	~IsingParameters();
	int LatticeShape[N_DIM];
	int NumSites(bool force_calc = false);
	int ProjectionArea(int axis);
	void GetSiteCoordinates(int site, int* res);
	int SiteID(int* site_coords);
	bool UsePBC;
	double K;
	double n;
	double Tau0;
	double Omega;
	double Beta;
	double AlphaAverage;
	Noise AlphaNoise;

	double Gamma0();
	double Gammac();
	double Kc();
	double gammac();
	
	void Initialize(ConfigParams &params);
	void CopyFrom(IsingParameters params);
	double GetMeanFieldGamma(double rate);
private:
	int _num_sites;
};

#endif // !ISING_PARAMETERS_H
