#include "Noise.h"

Noise::Noise()
{
	Initialize(NoiseTypes::NONOISE);
}

Noise::~Noise()
{
}

Noise::Noise(int type, double avg) {
	Initialize(type, avg);
}

Noise::Noise(int type, double* params, double avg) {
	Initialize(type, avg, params);
}

void Noise::Initialize(int type, double avg, double* params) {
	_avg = avg;
	_type = type;
	_params = params;
	NumParams(true);
}

void Noise::CopyFrom(Noise old_noise) {
	_avg = old_noise.GetAverage();
	_type = old_noise.GetType();
	_params = old_noise.GetParameters();
	NumParams(true);
}

double Noise::GetAverage() {
	return _avg;
}

int Noise::GetType() {
	return _type;
}

double* Noise::GetParameters() {
	return _params;
}

int Noise::GetParameters(double* res) {
	res = _params;
	return _num_params;
}

double Noise::GetParameter(int index) {
	if (index >= 0 && index < _num_params) {
		return _params[index];
	}
	else {
		return -1;
	}
}

int Noise::NumParams(bool force_calc) {
	if (force_calc) {
		if (_type == NoiseTypes::NONOISE) {
			_num_params = 0;
		}
		else if (_type == NoiseTypes::WHITE_FLAT) {
			_num_params = 1;
		}
		else if (_type == NoiseTypes::WHITE_GAUSS) {
			_num_params = 1;
		}
		else if (_type == NoiseTypes::WHITE_LOGNORM) {
			_num_params = 1;
		}
	}
	return _num_params;
}

void Noise::Sample(int num_samples, double* result) {
	//result = new double[num_samples];
	if (_type == NoiseTypes::NONOISE) {
		for (int i = 0; i < num_samples; i++) {
			result[i] = _avg;
		}
	} 
	else if (_type == NoiseTypes::WHITE_FLAT) {
		double variance = _params[0];
		if (_avg != 0) {
			variance = abs(variance * _avg);
		}
		double amplitude = sqrt(3 * variance);
		for (int i = 0; i < num_samples; i++) {
			result[i] = _avg + 2 * amplitude * ((double)rand() / (RAND_MAX)) - amplitude;
		}
	}
	else if (_type == NoiseTypes::WHITE_GAUSS) {
		double variance = _params[0] * _avg * _avg;
		std::random_device _rd{};
		std::mt19937 _gen{ _rd() };
		std::normal_distribution<> d{ _avg, sqrt(variance) };
		for (int i = 0; i < num_samples; i++) {
			result[i] = d(_gen);
		}
	}
	else if (_type == NoiseTypes::WHITE_LOGNORM) {
		/*
		Lognormal distribution: 
		     X = exp(mu+sqrt(sigma2)*Z)
		where:
		- Z is a standard normal variable
		- mu is the average of ln(X)
		- sigma2 is the variance of ln(X)
		Aritmetic moments of the distribution:
		- <X> = exp(mu+0.5*sigma2)
		- Var(X) = exp(2*mu+sigma2)*(exp(sigma2)-1)
		- Var(X)/<X>^2 = exp(sigma2) - 1
		Parameters (mu, sigma2) from distribution moments (<X>=mean, Var(X)/<X>^2=normvar):
		- sigma2 = ln(normvar + 1)
		- mu = ln(mean/sqrt(normvar+1)) = ln(mean) - 0.5 * sigma2
		*/
		double _sigma2 = log(_params[0] + 1.0);
		double _mu = log(_avg) - 0.5 * _sigma2;
		std::random_device _rd{};
		std::mt19937 _gen{ _rd() };
		std::normal_distribution<> Z{ _mu, sqrt(_sigma2) };
		for (int i = 0; i < num_samples; i++) {
			double _exponent = Z(_gen);
			result[i] = exp(_exponent);
		}
	}
}