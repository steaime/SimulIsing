#pragma once
#ifndef NOISE_H
#define NOISE_H

#include "stdafx.h"
#include "Constants.h"
#include "ConfigReader.h"





class Noise
{
public:
	Noise();
	Noise(int type, double avg = 0.0);
	Noise(int type, double* params, double avg = 0.0);
	//Noise(std::string sParamFile);
	//Noise(ConfigParams &params);
	~Noise();

	double GetAverage();
	int GetType();
	double* GetParameters();
	int GetParameters(double* res);
	double GetParameter(int index);

	//void Initialize(ConfigParams &conf_reader);
	void Initialize(int type, double avg = 0.0, double* params=NULL);
	void CopyFrom(Noise old_noise);
	void Sample(int num_samples, double* result);
	int NumParams(bool force_calc = false);

private:
	double _avg;
	int _type;
	int _num_params;
	double* _params;

};


#endif // !NOISE_H
