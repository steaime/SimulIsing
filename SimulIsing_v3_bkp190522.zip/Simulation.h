#pragma once
#ifndef SIMULATION_H
#define SIMULATION_H

#include "stdafx.h"
#include "IsingParameters.h"
#include "InitialConditions.h"
#include "Noise.h"
#include "MontecarloParameters.h"
#include "Constants.h"
#include "SharedFunctions.h"


class Simulation
{
public:
	Simulation();
	Simulation(int n_sites, bool use_pbc, double omega, double K, double tau0,
		double alpha, double beta, int alpha_noise_type, double* alpha_noise_params,
		int init_noise_type, double* init_noise_params, double effective_T = DEF_SIM_TEMP);
	Simulation(IsingParameters model_parameters, Noise init_conditions, MCParams &tstep_params);
	~Simulation();
	void Setup(IsingParameters model_parameters, Noise init_conditions, MCParams &tstep_params);
	void Clear();

	IsingParameters GetParams();
	Noise GetInitNoise();
	int UpdateParams(IsingParameters new_params);
	bool ValidateParams(IsingParameters &params);

	void Initialize();
	void InitializeAlpha();
	void GenInitialConditions();
	int ValidateRates();
	int ValidateAlphas();

	int IsSiteOnEdge(int site);
	void FindEdgesSite(int site, int* axes);
	int GetNNNumber(int site, bool force_calc = false);
	void GetNNAddress(int site, int** address, int* number = NULL, bool force_calc = false);
	void UpdateNearestNeighbors();
	void UpdateNNNumber();
	void UpdateNNAddress();

	double** GetAlphas();
	double* GetRates();
	double* GetTargetRates(bool update = true);
	void UpdateTargetRates();
	void UpdateTargetRate(int site);
	double GetAlpha(int site_i, int site_j);
	double GetAlphaNN(int site_i, int neighbor_index);
	double GetRate(int site);
	double GetTargetRate(int site, bool force_calc = false);

	double GetMeanFieldRate(double gamma = -1, double start_rate = -1, double precision = DEF_SIM_CONV_PREC);

	double GetAverageRate(bool force_calc = false);
	double GetRateStd();
	double GetTauStd(bool statistic = true);
	double GetAverageAlpha();

	double GetTemperature();
	int GetMaxStepNum();
	int GetMaxStepPerRun();
	int GetEquilibrationProtocol();
	int GetEquilibrationParameterNumber();
	double* GetEquilibrationParameters();
	int SetEquilibrationProtocol(int newProtocol, double* protocolParams);
	int SetEquilibrationRunNumber(int new_val);

	double GetGamma();
	int SetGamma(double new_gamma, bool adjust_lattice = true);

	int SimStep(bool ForceUpdateAvRate = false, double* rate_change = NULL);
	int AdjustLattice(double** eqDetails = NULL, bool** blnFastSites = NULL);

	bool GetForceMeanField();
	void SetForceMeanField(bool val);
	bool IsFastSite(int site, double thr_rate_ratio = MAX_SOLID_RATE_RATIO);
	bool IsSlowSite(int site, double thr_rate_ratio = MAX_SOLID_RATE_RATIO);

	int GetNumSites(bool force_calc = false);
	int GetNumSlowSites(double thr_rate_ratio = MAX_SOLID_RATE_RATIO);
	double GetFractionSlowSites(double thr_rate_ratio = MAX_SOLID_RATE_RATIO);
	int GetNumFastSites(double thr_rate_ratio = MAX_SOLID_RATE_RATIO);
	double GetFractionFastSites(double thr_rate_ratio = MAX_SOLID_RATE_RATIO);
	void GetSiteCoordinates(int site, int* res);

	int GetRateCorrelation(double* res, int* x = NULL, int num_x = -1);

	int GetStatus();
	int ID();
	int StepCount();

private:
	IsingParameters _params;
	Noise _init_noise;
	MCParams _mc_params;
	double _gamma;
	double** _alpha = NULL;
	double* _rates = NULL;
	double* _target_rates = NULL;
	double* _rate_step = NULL;
	double _avg_rate;
	int* _nn_number = NULL;
	int** _nn_address = NULL;
	bool _force_meanfield;
	int _ID = -1;
	int _status = SimStatus::NOT_INITIALIZED;
	int _count_iter;

	bool _UseMeanfield(int site = -1);
};

#endif // !LATTICE_H

