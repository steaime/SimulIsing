#pragma once
#ifndef STDAFX_H
#define STDAFX_H

#include <iostream>
#include <iomanip>
#include <ctime>
#include <map>
#include <random>
#include <chrono>
#include <math.h>
#include <cstring>
#include <fstream>
#include <string>
#include <stdio.h>
#include <thread>
#include "CImg.h"
#include "INIReader.h"

#endif
